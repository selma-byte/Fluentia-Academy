# Smansys Appo - Project Documentation for FlutterFlow

This document provides a comprehensive overview of the `smansys-appo` project architecture, database schema, state management, and component structure. It is designed to be passed directly to FlutterFlow (or AI tools assisting with FlutterFlow) to serve as a blueprint for migrating or rebuilding the application for mobile devices.

## 1. Project Overview
`smansys-appo` (Polyglot Academy) is a comprehensive school/academy management system built with React, Vite, Tailwind CSS, and Supabase. The system supports full CRUD operations, role-based access control, scheduling, communication, and payments.

**Primary App Goal:** Manage students, staff, classes, attendance, grades, appointments, and financial transactions across four distinct user roles.

## 2. User Roles & Dashboards
The application implements routing and dashboard separation based on four core roles:
- **Admin (`/admin/dashboard`)**: Full system access, management of users, settings, and complex financial reporting.
- **Secretary (`/secretary/dashboard`)**: Operations-focused. Management of enrollments, appointments, scheduling, student/staff records, and daily tasks.
- **Teacher (`/teacher/dashboard`)**: Classroom-focused. Management of grades, attendance, class schedules, and direct student communication.
- **Student/Parent (`/student-parent`)**: Consumer-focused. Views grades, attendance, homework, announcements, and manages payments.

## 3. Database Schema (Supabase)
The application relies directly on Supabase for BaaS (Backend as a Service). The following core tables and relationships should be replicated in the FlutterFlow database/Supabase integration:

### Core Tables:
1.  **`users` / Authentication**: Handled natively by Supabase Auth (Emails, Passwords).
2.  **`staff`**:
    *   Fields: `id`, `name`, `email`, `role` (Admin, Secretary, Teacher), `phone`, etc.
3.  **`students`**:
    *   Fields: `id`, `name`, `email`, `group_name`, `status` (Active, Inactive), `parent_id` (foreign key if applicable).
4.  **`classes`**:
    *   Fields: `id`, `name`, `teacher_name`, `schedule`, `enrolled_count`, `capacity`, `room_id`.
5.  **`appointments`**:
    *   Fields: `id`, `user_id`, `type`, `date`, `time`, `status` (Pending, Confirmed, Cancelled).
6.  **`communications`**:
    *   Fields: `id`, `sender_id`, `receiver_id`, `type` (message, announcement), `content`, `created_at`.
7.  **`attendance`**:
    *   Fields: `id`, `student_id`, `class_id`, `date`, `status` (Present, Absent, Late).
8.  **`grades` / `exams`**:
    *   Fields: `id`, `student_id`, `class_id`, `exam_id`, `score`, `remarks`.
9.  **`rooms`**:
    *   Fields: `id`, `name`, `capacity`.
10. **`tasks`**:
    *   Fields: `id`, `assigned_to`, `title`, `description`, `status`.
11. **`library_resources` / `lectures`**:
    *   Fields: `id`, `class_name`, `title`, `file_url`, `type`.

## 4. Key Workflows & Features to Implement in FlutterFlow

### A. Authentication & Onboarding
*   **Sign up / Login**: Users must be routed to their respective dashboards (`Admin`, `Secretary`, `Teacher`, `StudentParent`) immediately upon login by checking the `role` field in the `staff` or `students` table.

### B. Secretary / Admin Workflows
*   **Student Registration & CRUD**: Forms to create new students, update their info, and delete them. Requires database writes to the `students` table.
*   **Enrollment Management**: Assigning students to `classes`. Requires updating the `enrolled_count` on the `classes` table and setting the `group_name` on the `students` table.
*   **Scheduling Hub**: Resolving schedule conflicts by querying the `classes` table for overlapping times and `rooms`.
*   **Payments & Finance**: Tracking student payments and staff salaries.

### C. Teacher Workflows
*   **Classroom Management**: A view querying `classes` where `teacher_name` matches the logged-in user.
*   **Taking Attendance**: A checklist interface pushing records to the `attendance` table for a specific class and date.
*   **Grading System**: Forms to input scores for exams, pushing data to the `grades` table.

### D. Student & Parent Portal
*   **Dashboard View**: Read-only views of `grades`, `attendance`, and `classes` filtered by the logged-in student's ID.
*   **Communication Hub**: A chat interface interacting with the `communications` table, filtering for messages sent to or from the student/parent, alongside global announcements.

## 5. State Management & Data Fetching
*   **Current Web Architecture**: The app uses `useState`/`useEffect` hooks to fetch data asynchronously via `supabase.from('table').select('*')` directly within components.
*   **FlutterFlow Equivalent**: In FlutterFlow, this translates directly to **Backend Queries (Supabase)** on pages or UI lists, utilizing standard FlutterFlow Supabase integration to bind queries to UI elements (ListViews, DataTables).

## 6. Design & Styling Notes
*   **Theme**: The login and landing pages use a dark theme (`bg-[#0A1128]`) with blue/purple accents (`#2D428B`, `#A78BFA`).
*   **Components**: Dashboards rely heavily on sidebar navigation, data tables, metric cards, and modal popups. In FlutterFlow, utilize standard `Drawer` menus, `Card` widgets, `ListView` for tables, and `BottomSheets` or `Alerts` for modals to replicate the web experience natively on mobile.
