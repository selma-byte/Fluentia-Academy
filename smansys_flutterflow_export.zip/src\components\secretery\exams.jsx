import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabaseClient'; 

const Exams = ({ examView, setExamView }) => {
  const [createStep, setCreateStep] = useState(1);
  const [examsData, setExamsData] = useState([]);
  const [loading, setLoading] = useState(true);

  // States للبحث والفلترة 
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All Status');

  // 💡 States للاقسام والأساتذة من الداتا باز
  const [classesData, setClassesData] = useState([]);
  const [teachersData, setTeachersData] = useState([]);

  // State لمعلومات الامتحان اللي رانا نكرييو فيه
  const [newExam, setNewExam] = useState({
    title: '',
    subject: 'English',
    class_name: '',
    teacher_id: '', 
    duration: 60,
    instructions: ''
  });

  const [resultsData, setResultsData] = useState([]);
  const [selectedResultExam, setSelectedResultExam] = useState('');
  const [resultStats, setResultStats] = useState({ total: 0, completed: 0, avg: 0, passRate: 0 });

  // =======================================
  // 1. جلب البيانات من قاعدة البيانات
  // =======================================
  const fetchExams = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('exams')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setExamsData(data);
    }
    setLoading(false);
  };

  const fetchClassesAndTeachers = async () => {
    const { data: cData } = await supabase.from('classes').select('*');
    if (cData) {
      setClassesData(cData);
      if (cData.length > 0) setNewExam(prev => ({ ...prev, class_name: cData[0].name }));
    }

    const { data: tData } = await supabase.from('staff').select('*');
    if (tData) {
      setTeachersData(tData);
      if (tData.length > 0) setNewExam(prev => ({ ...prev, teacher_id: tData[0].id }));
    }
  };

  const fetchExamResults = async (examTitle) => {
    if (!examTitle) return;
    try {
      // 💡 جلب النتائج بطريقة مباشرة تضمن عرض الأسماء حتى لو فشل الربط المعقد
      const { data, error } = await supabase
        .from('grades')
        .select('*')
        .eq('exam_title', examTitle);
        
      if (error) {
        console.error("🚨 Supabase Error:", error);
        return;
      }

      if (data && data.length > 0) {
        setResultsData(data);
        const total = data.length;
        const completed = data.filter(d => d.score != null).length;
        let sumScores = 0;
        let passedCount = 0;
        
        data.forEach(d => {
          const scoreNum = parseFloat(d.score) || 0;
          sumScores += scoreNum;
          if (scoreNum >= 50 || d.status === 'Passed') passedCount++;
        });

        setResultStats({
          total,
          completed,
          avg: total ? (sumScores / total).toFixed(1) : 0,
          passRate: total ? ((passedCount / total) * 100).toFixed(1) : 0
        });
      } else {
        setResultsData([]);
        setResultStats({ total: 0, completed: 0, avg: 0, passRate: 0 });
      }
    } catch (err) {
      console.log("Error fetching grades", err);
    }
  };

  useEffect(() => {
    fetchExams();
    fetchClassesAndTeachers();
  }, []);

  useEffect(() => {
    if (examView === 'results') {
      const completedExams = examsData.filter(e => e.status?.toLowerCase() === 'completed');
      if (completedExams.length > 0 && !selectedResultExam) {
        setSelectedResultExam(completedExams[0].title);
        fetchExamResults(completedExams[0].title);
      } else if (selectedResultExam) {
        fetchExamResults(selectedResultExam);
      }
    }
  }, [examView, selectedResultExam, examsData]);

  // =======================================
  // 2. دالة حفظ الامتحان + التحقق
  // =======================================
  const handleSaveExam = async () => {
    if (!newExam.title || !newExam.class_name || !newExam.teacher_id) {
      alert("Please fill all required fields (Title, Class, Teacher)!");
      return;
    }
    
    setLoading(true);
    try {
      const todayDate = new Date().toISOString().split('T')[0];

      const { data: existingExams, error: checkError } = await supabase
        .from('exams')
        .select('*')
        .eq('class_name', newExam.class_name)
        .eq('exam_date', todayDate);

      if (checkError) throw checkError;

      if (existingExams && existingExams.length > 0) {
        alert(`❌ Conflict! The class "${newExam.class_name}" already has an exam scheduled on this date.`);
        setLoading(false);
        return;
      }

      const { error } = await supabase.from('exams').insert([{
        title: newExam.title,
        subject: newExam.subject,
        class_name: newExam.class_name,
        teacher_id: newExam.teacher_id,
        duration_minutes: parseInt(newExam.duration),
        status: 'Active', 
        exam_date: todayDate,
        instructions: newExam.instructions
      }]);

      if (error) throw error;
      
      alert("✅ Exam Created Successfully!");
      setNewExam({ title: '', subject: 'English', class_name: classesData[0]?.name || '', teacher_id: teachersData[0]?.id || '', duration: 60, instructions: '' });
      setCreateStep(1);
      setExamView('manage'); 
      fetchExams(); 
    } catch (err) {
      alert("Error: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsCompleted = async (id) => {
    if(window.confirm("Mark this exam as Completed? It will now appear in the Results section.")) {
      const { error } = await supabase.from('exams').update({ status: 'Completed' }).eq('id', id);
      if(!error) {
        setExamsData(examsData.map(exam => exam.id === id ? { ...exam, status: 'Completed' } : exam));
      } else {
        alert("Error updating exam: " + error.message);
      }
    }
  };

  const handleDeleteExam = async (id) => {
    if(window.confirm("Are you sure you want to delete this exam?")) {
      const { error } = await supabase.from('exams').delete().eq('id', id);
      if(!error) {
        setExamsData(examsData.filter(exam => exam.id !== id));
      } else {
        alert("Error deleting exam: " + error.message);
      }
    }
  };

  const totalExams = examsData.length;
  const activeExams = examsData.filter(e => e.status?.toLowerCase() === 'active').length;
  const scheduledExams = examsData.filter(e => e.status?.toLowerCase() === 'scheduled').length;
  const completedExams = examsData.filter(e => e.status?.toLowerCase() === 'completed').length;

  const filteredExams = examsData.filter(exam => {
    const matchesSearch = (exam.title?.toLowerCase() || '').includes(searchTerm.toLowerCase()) || 
                          (exam.subject?.toLowerCase() || '').includes(searchTerm.toLowerCase()) || 
                          (exam.class_name?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All Status' || (exam.status?.toLowerCase() || 'draft') === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  // =======================================
  // 3. الصفحة الرئيسية (Dashboard)
  // =======================================
  const renderHome = () => (
    <div className="animate-fade-in pb-10">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-[#0A1128]">Exam Management</h2>
        <button onClick={fetchExams} className="bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded-lg text-sm font-bold transition-colors cursor-pointer">
          🔄 Refresh
        </button>
      </div>
      
      <div className="flex justify-between items-center bg-white p-6 rounded-2xl border border-gray-200 shadow-sm mb-10">
        <div className="text-center px-6">
          <p className="text-gray-500 text-sm font-bold mb-2">Total Exams</p>
          <p className="text-4xl font-bold text-[#0A1128]">{loading ? '...' : totalExams}</p>
        </div>
        <div className="w-px h-12 bg-gray-200"></div>
        <div className="text-center px-6">
          <p className="text-gray-500 text-sm font-bold mb-2">Active Exams</p>
          <p className="text-4xl font-bold text-[#0A1128]">{loading ? '...' : activeExams}</p>
        </div>
        <div className="w-px h-12 bg-gray-200"></div>
        <div className="text-center px-6">
          <p className="text-gray-500 text-sm font-bold mb-2">Scheduled</p>
          <p className="text-4xl font-bold text-[#0A1128]">{loading ? '...' : scheduledExams}</p>
        </div>
        <div className="w-px h-12 bg-gray-200"></div>
        <div className="text-center px-6">
          <p className="text-gray-500 text-sm font-bold mb-2">Completed</p>
          <p className="text-4xl font-bold text-[#0A1128]">{loading ? '...' : completedExams}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h3 className="text-xl font-bold text-[#0A1128] mb-6">Recent Exams</h3>
          <div className="space-y-4">
            {loading ? (
              <p className="text-gray-400 font-bold italic">Loading...</p>
            ) : examsData.length === 0 ? (
              <div className="bg-gray-50 border border-dashed border-gray-300 rounded-xl p-8 text-center">
                <p className="text-gray-500 font-bold mb-2">No exams created yet.</p>
              </div>
            ) : (
              examsData.slice(0, 5).map((exam) => (
                <div 
                  key={exam.id} 
                  onClick={() => exam.status?.toLowerCase() === 'completed' ? setExamView('results') : setExamView('manage')}
                  className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow flex justify-between items-center cursor-pointer"
                >
                  <div>
                    <div className="flex items-center mb-2">
                      <h4 className="font-bold text-[#0A1128] text-base mr-3">{exam.title}</h4>
                      <span className={`text-[10px] px-2.5 py-1 rounded font-bold capitalize tracking-wider ${
                        exam.status?.toLowerCase() === 'active' ? 'bg-[#0A1128] text-white' : 
                        exam.status?.toLowerCase() === 'scheduled' ? 'bg-orange-50 text-orange-600 border border-orange-200' : 'bg-gray-100 text-gray-500'
                      }`}>{exam.status || 'Draft'}</span>
                    </div>
                    <p className="text-sm text-gray-500">{exam.subject} • {exam.class_name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-400 capitalize mb-1">Date</p>
                    <p className="text-sm font-medium text-gray-700">{exam.exam_date || 'TBD'}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold text-[#0A1128] mb-6">Quick Actions</h3>
          <div className="bg-transparent space-y-3">
            <button onClick={() => {setExamView('create'); setCreateStep(1);}} className="w-full text-left px-4 py-4 rounded-xl hover:bg-gray-100 text-base font-medium text-gray-700 transition-colors flex items-center cursor-pointer">
              <span className="mr-3 text-gray-500 text-xl">+</span> Create New Exam
            </button>
            <button onClick={() => setExamView('manage')} className="w-full text-left px-4 py-4 rounded-xl hover:bg-gray-100 text-base font-medium text-gray-700 transition-colors flex items-center cursor-pointer">
              <span className="mr-3 text-gray-500 text-xl">⚙️</span> Manage Exams
            </button>
            <button onClick={() => setExamView('results')} className="w-full text-left px-4 py-4 rounded-xl hover:bg-gray-100 text-base font-medium text-gray-700 transition-colors flex items-center cursor-pointer">
              <span className="mr-3 text-gray-500 text-xl">📊</span> View Exam Results
            </button>
            <button onClick={() => setExamView('schedule')} className="w-full text-left px-4 py-4 rounded-xl hover:bg-gray-100 text-base font-medium text-gray-700 transition-colors flex items-center cursor-pointer">
              <span className="mr-3 text-gray-500 text-xl">📅</span> Schedule Exam
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // =======================================
  // 4. صفحة إدارة الامتحانات (Manage View)
  // =======================================
  const renderManageExams = () => (
    <div className="animate-fade-in pb-10 max-w-7xl mx-auto">
      <div className="mb-6 border-b border-gray-200 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#0A1128] mb-1">Exam Management</h2>
          <p className="text-sm text-gray-500">Manage all exams across the school</p>
        </div>
        <button onClick={() => {setExamView('create'); setCreateStep(1);}} className="bg-[#2563eb] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-md hover:bg-blue-700 transition-colors cursor-pointer">
          + New Exam
        </button>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="bg-gray-100/80 rounded-2xl p-5 flex justify-between items-start border border-gray-200/50">
          <div><p className="text-gray-500 text-[11px] font-medium mb-1">Total Exams</p><p className="text-2xl font-bold text-[#0A1128]">{loading ? '-' : totalExams}</p></div>
          <span className="text-blue-500 text-xl">📄</span>
        </div>
        <div className="bg-gray-100/80 rounded-2xl p-5 flex justify-between items-start border border-gray-200/50">
          <div><p className="text-gray-500 text-[11px] font-medium mb-1">Active Exams</p><p className="text-2xl font-bold text-[#0A1128]">{loading ? '-' : activeExams}</p></div>
          <span className="text-green-500 text-xl">▶</span>
        </div>
        <div className="bg-gray-100/80 rounded-2xl p-5 flex justify-between items-start border border-gray-200/50">
          <div><p className="text-gray-500 text-[11px] font-medium mb-1">Scheduled</p><p className="text-2xl font-bold text-[#0A1128]">{loading ? '-' : scheduledExams}</p></div>
          <span className="text-orange-500 text-xl">📅</span>
        </div>
        <div className="bg-gray-100/80 rounded-2xl p-5 flex justify-between items-start border border-gray-200/50">
          <div><p className="text-gray-500 text-[11px] font-medium mb-1">Completed</p><p className="text-2xl font-bold text-[#0A1128]">{loading ? '-' : completedExams}</p></div>
          <span className="text-purple-500 text-xl">📋</span>
        </div>
      </div>

      <div className="bg-gray-100/80 rounded-xl p-3 flex justify-between items-center border border-gray-200/50 mb-10">
        <div className="relative flex-1 max-w-lg">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 text-sm">🔍</span>
          <input 
            type="text" 
            placeholder="Search exams by title, subject, or class..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent border-none py-2 pl-10 pr-4 text-sm outline-none text-gray-600" 
          />
        </div>
        <div className="bg-gray-200/50 rounded-lg px-3 py-1.5 flex items-center">
          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-transparent border-none text-sm font-medium text-gray-600 outline-none cursor-pointer pr-2"
          >
            <option>All Status</option>
            <option>Active</option>
            <option>Scheduled</option>
            <option>Completed</option>
            <option>Draft</option>
          </select>
        </div>
      </div>

      <div className="overflow-x-auto bg-white border border-gray-200 rounded-2xl shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 border-b border-gray-200 text-[#0A1128] font-bold">
            <tr>
              <th className="py-4 px-4">Title</th>
              <th className="py-4 px-4">Subject</th>
              <th className="py-4 px-4">Class</th>
              <th className="py-4 px-4">Status</th>
              <th className="py-4 px-4">Duration</th>
              <th className="py-4 px-4">Date</th>
              <th className="py-4 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredExams.length === 0 ? ( 
              <tr><td colSpan="7" className="text-center py-10 text-gray-400 font-bold">No exams found.</td></tr>
            ) : (
              filteredExams.map((row) => (
                <tr key={row.id} className="hover:bg-gray-50/50 transition-colors cursor-pointer">
                  <td className="py-4 px-4">
                    <p className="font-bold text-[#0A1128] text-[13px]">{row.title}</p>
                    <p className="text-[10px] text-gray-400 mt-0.5">Created: {new Date(row.created_at).toLocaleDateString()}</p>
                  </td>
                  <td className="py-4 px-4 text-gray-700 text-xs font-medium">{row.subject}</td>
                  <td className="py-4 px-4 text-gray-700 text-xs font-medium">{row.class_name}</td>
                  <td className="py-4 px-4">
                    {row.status?.toLowerCase() === 'active' && <span className="bg-[#0A1128] text-white px-2.5 py-1 rounded text-[10px] font-bold flex items-center w-max">▶ Active</span>}
                    {row.status?.toLowerCase() === 'scheduled' && <span className="text-gray-600 border border-gray-200 px-2.5 py-1 rounded text-[10px] font-bold flex items-center w-max">📅 Scheduled</span>}
                    {row.status?.toLowerCase() === 'completed' && <span className="text-green-600 border border-green-200 bg-green-50 px-2.5 py-1 rounded text-[10px] font-bold flex items-center w-max">📋 Completed</span>}
                    {(!row.status || row.status?.toLowerCase() === 'draft') && <span className="text-gray-500 px-2.5 py-1 rounded text-[10px] font-bold flex items-center w-max">⚙️ Draft</span>}
                  </td>
                  <td className="py-4 px-4 text-gray-500 text-xs"><span className="mr-1.5 opacity-50">⏱</span> {row.duration_minutes}m</td>
                  <td className="py-4 px-4">
                     <p className="text-xs text-gray-600 font-bold">{row.exam_date || 'TBD'}</p>
                  </td>
                  <td className="py-4 px-4 text-gray-400 space-x-3 text-sm text-center">
                     {row.status?.toLowerCase() === 'active' && (
                       <span className="hover:text-green-500 cursor-pointer mr-2" title="Mark as Completed" onClick={(e) => { e.stopPropagation(); handleMarkAsCompleted(row.id); }}>✅</span>
                     )}
                     <span className="hover:text-blue-600 cursor-pointer">✏️</span>
                     <span className="hover:text-red-500 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleDeleteExam(row.id); }}>🗑</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  // =======================================
  // 5. صفحة إنشاء امتحان (Create View)
  // =======================================
  const renderCreateExam = () => (
    <div className="animate-fade-in max-w-4xl mx-auto pb-10">
      <div className="mb-10 border-b border-gray-200 pb-5">
        <h2 className="text-3xl font-bold text-[#0A1128] mb-2">Create New Exam</h2>
        <p className="text-sm text-gray-500">Create an exam by uploading a PDF and providing instructions</p>
      </div>

      <div className="flex items-center justify-center mb-12 space-x-6">
        <div className="flex items-center text-blue-600 font-bold text-base">
          <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center mr-3 text-sm">1</span>
          Exam Details
        </div>
        <div className={`w-20 h-0.5 ${createStep === 2 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
        <div className={`flex items-center text-base font-bold ${createStep === 2 ? 'text-blue-600' : 'text-gray-400'}`}>
          <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 text-sm ${createStep === 2 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>2</span>
          Upload PDF
        </div>
      </div>

      <div className="bg-gray-50/50 border border-gray-100 rounded-3xl p-10 shadow-sm">
        {createStep === 1 ? (
          <div className="animate-fade-in">
            <h3 className="text-xl font-bold text-[#0A1128] mb-2">Step 1: Exam Information</h3>
            <p className="text-sm text-gray-500 mb-8">Provide basic information about your exam</p>

            <div className="grid grid-cols-2 gap-x-10 gap-y-6 mb-8">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Exam Title <span className="text-red-500">*</span></label>
                <input type="text" value={newExam.title} onChange={e=>setNewExam({...newExam, title: e.target.value})} placeholder="e.g. English Mid-Term" className="w-full bg-gray-100 border border-gray-200 rounded-xl px-5 py-3 outline-none focus:border-blue-500 text-sm font-bold" required/>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Subject</label>
                <select value={newExam.subject} onChange={e=>setNewExam({...newExam, subject: e.target.value})} className="w-full bg-gray-100 border border-gray-200 rounded-xl px-5 py-3 outline-none focus:border-blue-500 text-sm font-bold cursor-pointer">
                  <option>English</option><option>French</option><option>German</option><option>Spanish</option><option>Physics</option><option>Mathematics</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Class / Group <span className="text-red-500">*</span></label>
                <select value={newExam.class_name} onChange={e=>setNewExam({...newExam, class_name: e.target.value})} className="w-full bg-gray-100 border border-gray-200 rounded-xl px-5 py-3 outline-none focus:border-blue-500 text-sm font-bold cursor-pointer">
                  <option value="">-- Select Class --</option>
                  {classesData.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Assign Teacher <span className="text-red-500">*</span></label>
                <select value={newExam.teacher_id} onChange={e=>setNewExam({...newExam, teacher_id: e.target.value})} className="w-full bg-gray-100 border border-gray-200 rounded-xl px-5 py-3 outline-none focus:border-blue-500 text-sm font-bold cursor-pointer">
                  <option value="">-- Select Teacher --</option>
                  {teachersData.map(t => (
                    <option key={t.id} value={t.id}>{t.first_name} {t.last_name}</option>
                  ))}
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-sm font-bold text-gray-700 mb-2">Duration (minutes)</label>
                <input type="number" value={newExam.duration} onChange={e=>setNewExam({...newExam, duration: e.target.value})} placeholder="60" className="w-full bg-gray-100 border border-gray-200 rounded-xl px-5 py-3 outline-none focus:border-blue-500 text-sm font-bold" />
              </div>
            </div>
            
            <div className="mb-10">
              <label className="block text-sm font-bold text-gray-700 mb-2">Exam Instructions</label>
              <textarea value={newExam.instructions} onChange={e=>setNewExam({...newExam, instructions: e.target.value})} rows="4" placeholder="Instructions here..." className="w-full bg-gray-100 border border-gray-200 rounded-xl px-5 py-3 outline-none focus:border-blue-500 text-sm font-bold resize-none"></textarea>
            </div>
            <div className="flex justify-between border-t border-gray-200 pt-8">
              <button className="text-gray-400 font-medium text-sm cursor-not-allowed">Previous</button>
              <button onClick={() => {
                if(!newExam.title || !newExam.class_name || !newExam.teacher_id) { alert("Title, Class, and Teacher are required!"); return; }
                setCreateStep(2);
              }} className="bg-[#0A1128] text-white px-8 py-3 rounded-xl text-sm font-bold hover:bg-blue-900 transition-colors cursor-pointer">Next Step</button>
            </div>
          </div>
        ) : (
          <div className="animate-fade-in py-6">
            <h3 className="text-xl font-bold text-[#0A1128] mb-2">Step 2: Upload Exam PDF</h3>
            <p className="text-sm text-gray-500 mb-8">Upload the PDF containing your exam questions</p>
            
            <div className="border-2 border-dashed border-blue-200 rounded-2xl p-20 mb-10 bg-blue-50/30 hover:bg-blue-50 transition-colors cursor-pointer flex flex-col items-center">
               <span className="text-5xl text-blue-400 mb-6">📤</span>
               <p className="font-bold text-[#0A1128] text-lg mb-2">Upload Exam PDF</p>
               <p className="text-sm text-gray-500 mb-6">Upload the PDF containing the exam questions (Max 5MB)</p>
               <button className="bg-white text-blue-600 px-6 py-2.5 rounded-xl text-sm font-bold border border-blue-200 flex items-center shadow-sm">
                 <span className="mr-2 text-lg">↑</span> Choose PDF File
               </button>
            </div>

            <div className="flex justify-between border-t border-gray-200 pt-8">
              <button onClick={() => setCreateStep(1)} className="text-gray-600 font-bold text-sm hover:text-black cursor-pointer">Previous</button>
              <button onClick={handleSaveExam} disabled={loading} className="bg-[#2563eb] text-white px-10 py-3 rounded-xl text-sm font-bold hover:bg-blue-700 transition-colors cursor-pointer shadow-lg active:scale-95">
                {loading ? 'Saving...' : 'Finish & Save Exam'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // =======================================
  // 6. صفحة نتائج الامتحانات (Results View)
  // =======================================
  const renderResults = () => {
    const completedExamsList = examsData.filter(e => e.status?.toLowerCase() === 'completed');
    const currentExamDetails = completedExamsList.find(e => e.title === selectedResultExam);

    return (
      <div className="animate-fade-in pb-10">
        <div className="mb-8 border-b border-gray-200 pb-5">
          <h2 className="text-3xl font-bold text-[#0A1128] mb-2">Exam Results</h2>
          <p className="text-sm text-gray-500">View and analyze student performance across all exams</p>
        </div>

        <div className="flex justify-between items-center mb-8">
          <select 
            value={selectedResultExam}
            onChange={(e) => setSelectedResultExam(e.target.value)}
            className="bg-transparent text-[#0A1128] font-bold text-base outline-none cursor-pointer w-80"
          >
            {completedExamsList.length === 0 ? (
               <option value="">No completed exams yet</option>
            ) : (
               completedExamsList.map(exam => (
                 <option key={exam.id} value={exam.title}>{exam.title} - {exam.class_name}</option>
               ))
            )}
          </select>
          <div className="flex space-x-6">
            <button className="text-sm font-bold text-gray-600 hover:text-black flex items-center cursor-pointer transition-colors">
              <span className="mr-2 text-lg">📥</span> Export CSV
            </button>
            <button className="text-sm font-bold text-gray-600 hover:text-black flex items-center cursor-pointer transition-colors">
              <span className="mr-2 text-lg">📥</span> Export PDF
            </button>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-6 mb-10 flex divide-x divide-gray-100">
          <div className="flex-1 px-6 flex justify-between items-center">
            <div>
              <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-2">Total Students</p>
              <p className="text-4xl font-bold text-[#0A1128] leading-none">{resultStats.total}</p>
            </div>
            <span className="text-blue-500 text-3xl opacity-90">👥</span>
          </div>
          <div className="flex-1 px-8 flex justify-between items-center">
            <div>
              <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-2">Completed</p>
              <p className="text-4xl font-bold text-[#0A1128] leading-none">{resultStats.completed}</p>
            </div>
            <span className="text-blue-400 text-3xl opacity-90">📄</span>
          </div>
          <div className="flex-1 px-8 flex justify-between items-center">
            <div>
              <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-2">Average Score</p>
              <p className="text-4xl font-bold text-[#0A1128] leading-none">{resultStats.avg}%</p>
            </div>
            <span className="text-green-500 text-3xl opacity-90">📊</span>
          </div>
          <div className="flex-1 px-8 flex justify-between items-center">
            <div>
              <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-2">Pass Rate</p>
              <p className="text-4xl font-bold text-[#0A1128] leading-none">{resultStats.passRate}%</p>
            </div>
            <span className="text-orange-500 text-3xl opacity-90">🏅</span>
          </div>
        </div>

        {currentExamDetails && (
          <div className="mb-12 pl-2">
            <h3 className="font-bold text-[#0A1128] text-xl mb-2">{currentExamDetails.title}</h3>
            <p className="text-sm text-gray-500 mb-8">{currentExamDetails.subject} • {currentExamDetails.class_name} • Conducted on {currentExamDetails.exam_date}</p>
            
            <div className="grid grid-cols-3 gap-6 text-base max-w-3xl">
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-2">Duration</p>
                <p className="font-bold text-[#0A1128] text-lg">{currentExamDetails.duration_minutes} minutes</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-2">Passing Score</p>
                <p className="font-bold text-[#0A1128] text-lg">50%</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-2">Completion Rate</p>
                <p className="font-bold text-[#0A1128] text-lg">
                   {resultStats.total > 0 ? Math.round((resultStats.completed / resultStats.total) * 100) : 0}%
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="mb-6 bg-white/50 rounded-2xl p-5 border border-gray-100">
          <div className="mb-6 border-b border-gray-200 pb-4">
            <h3 className="font-bold text-[#0A1128] text-lg mb-1">Student Results</h3>
            <p className="text-sm text-gray-500">Detailed results for each student who attempted the exam</p>
          </div>
          
          <div className="flex justify-between items-center mb-6">
              <div className="relative w-80 bg-gray-50 rounded-lg">
                <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400 text-sm">🔍</span>
                <input type="text" placeholder="Search students by name or ID..." className="w-full bg-transparent py-2.5 pl-10 pr-4 text-sm outline-none text-gray-600" />
              </div>
              <select className="bg-transparent border-none py-2 text-sm font-bold text-gray-600 outline-none cursor-pointer">
                <option>All Grades</option>
              </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-gray-200 text-[#0A1128] font-bold">
                <tr>
                  <th className="py-4 px-3">Student</th>
                  <th className="py-4 px-3">Score</th>
                  <th className="py-4 px-3">Percentage</th>
                  <th className="py-4 px-3">Grade</th>
                  <th className="py-4 px-3">Status</th>
                  <th className="py-4 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {resultsData.length === 0 ? (
                   <tr><td colSpan="6" className="text-center py-8 text-gray-400 font-bold">No results recorded yet for this exam.</td></tr>
                ) : (
                  resultsData.map((s, i) => {
                    const studentName = s.student_name || 'Unknown Student';
                    const studentId = s.student_id || '-';
                    const scoreNum = parseFloat(s.score) || 0;
                    
                    return (
                      <tr key={i} className="hover:bg-gray-50/80 transition-colors">
                        <td className="py-4 px-3">
                          <p className="font-bold text-[#0A1128] text-base">{studentName}</p>
                          <p className="text-xs text-gray-500 mt-1">{studentId}</p>
                        </td>
                        <td className="py-4 px-3 font-medium text-[#0A1128]">{s.score != null ? `${s.score}/100` : '-'}</td>
                        <td className="py-4 px-3">
                          <div className="flex items-center">
                            <span className="font-bold text-[#0A1128] w-10">{scoreNum}%</span>
                            <div className="w-10 h-2 bg-blue-600 rounded-full ml-2"></div>
                          </div>
                        </td>
                        <td className={`py-4 px-3 font-bold ${s.grade === 'F' ? 'text-red-500' : 'text-green-500'}`}>{s.grade || '-'}</td>
                        <td className="py-4 px-3">
                          <span className={`px-3 py-1 text-xs font-bold uppercase rounded ${s.status === 'Failed' || scoreNum < 50 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                            {s.status || (scoreNum >= 50 ? 'Passed' : 'Failed')}
                          </span>
                        </td>
                        <td className="py-4 px-3 text-center">
                          <button className="text-gray-400 hover:text-[#0A1128] cursor-pointer text-lg">👁</button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  // =======================================
  // 7. صفحة جدول الامتحانات (Schedule View)
  // =======================================
  const renderSchedule = () => (
    <div className="animate-fade-in pb-10">
      <div className="mb-8 border-b border-gray-200 pb-5">
        <h2 className="text-3xl font-bold text-[#0A1128] mb-2">Exam Schedule</h2>
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-sm overflow-x-auto">
        <div className="min-w-[900px]">
          <div className="grid grid-cols-6 gap-4 mb-6 text-center border-b border-gray-100 pb-6">
            <div className="text-gray-400 font-bold text-sm">🕒 Time</div>
            <div><p className="text-blue-600 font-bold text-sm uppercase mb-1">Mon</p><p className="text-xl font-black text-[#0A1128]">Oct 23</p></div>
            <div><p className="text-gray-500 font-bold text-sm uppercase mb-1">Tue</p><p className="text-xl font-black text-[#0A1128]">Oct 24</p></div>
            <div><p className="text-gray-500 font-bold text-sm uppercase mb-1">Wed</p><p className="text-xl font-black text-[#0A1128]">Oct 25</p></div>
            <div><p className="text-gray-500 font-bold text-sm uppercase mb-1">Thu</p><p className="text-xl font-black text-[#0A1128]">Oct 26</p></div>
            <div><p className="text-gray-500 font-bold text-sm uppercase mb-1">Fri</p><p className="text-xl font-black text-[#0A1128]">Oct 27</p></div>
          </div>

          <div className="grid grid-cols-6 gap-4 text-base relative">
            <div className="space-y-20 text-gray-400 font-bold text-sm text-center pt-6">
              <div>10:00 AM</div>
              <div>12:00 PM</div>
              <div>02:00 PM</div>
              <div>04:00 PM</div>
            </div>

            <div className="relative">
              <div className="absolute top-4 w-full bg-green-50 border-l-4 border-green-500 p-4 rounded-r-xl shadow-sm">
                <p className="text-xs font-bold text-green-600 mb-2 uppercase tracking-wide">Level A1</p>
                <p className="font-bold text-[#0A1128] text-base mb-1">German Quiz</p>
                <p className="text-xs text-gray-500">Room 4 • Dr. Sara</p>
              </div>
              <div className="absolute top-48 w-full bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-xl shadow-sm">
                <p className="text-xs font-bold text-blue-600 mb-2 uppercase tracking-wide">Level B2</p>
                <p className="font-bold text-[#0A1128] text-base mb-1">English Test</p>
              </div>
            </div>

            <div className="relative">
              <div className="absolute top-12 w-full bg-orange-50 border-l-4 border-orange-500 p-4 rounded-r-xl shadow-sm">
                <p className="text-xs font-bold text-orange-600 mb-2 uppercase tracking-wide">Level C1</p>
                <p className="font-bold text-[#0A1128] text-base mb-1">Spanish Oral</p>
                <p className="text-xs text-gray-500">Room 2</p>
              </div>
            </div>

            <div className="relative">
              <div className="absolute top-4 w-full bg-green-50 border-l-4 border-green-500 p-4 rounded-r-xl shadow-sm">
                <p className="text-xs font-bold text-green-600 mb-2 uppercase tracking-wide">Level A1</p>
                <p className="font-bold text-[#0A1128] text-base mb-1">German Quiz</p>
              </div>
              <div className="absolute top-32 w-full bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-xl shadow-sm">
                <p className="text-xs font-bold text-blue-600 mb-2 uppercase tracking-wide">Level B2</p>
                <p className="font-bold text-[#0A1128] text-base mb-1">English Final</p>
                <p className="text-xs text-gray-500">Hall B</p>
              </div>
            </div>

            <div className="relative">
              <div className="absolute top-10 w-full bg-purple-50 border-l-4 border-purple-500 p-4 rounded-r-xl shadow-sm">
                <p className="text-xs font-bold text-purple-600 mb-2 uppercase tracking-wide">Level B1</p>
                <p className="font-bold text-[#0A1128] text-base mb-1">French Written</p>
                <p className="text-xs text-gray-500">Room 5</p>
              </div>
            </div>

            <div className="relative border-l border-dashed border-gray-200 pl-4">
               <div className="absolute top-32 w-full bg-gray-100 p-5 rounded-xl text-center border border-gray-200">
                <p className="text-sm font-bold text-gray-400 mt-2 uppercase tracking-widest">No Exams</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-8 h-full overflow-y-auto bg-transparent custom-scrollbar">
      {examView === 'home' && renderHome()}
      {examView === 'manage' && renderManageExams()}
      {examView === 'results' && renderResults()}
      {examView === 'create' && renderCreateExam()}
      {examView === 'schedule' && renderSchedule()}
    </div>
  );
};

export default Exams;